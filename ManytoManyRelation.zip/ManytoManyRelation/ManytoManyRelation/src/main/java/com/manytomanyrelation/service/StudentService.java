package com.manytomanyrelation.service;

import com.manytomanyrelation.dto.CourseDTO;
import com.manytomanyrelation.dto.StudentDTO;
import com.manytomanyrelation.entity.Course;
import com.manytomanyrelation.entity.Student;
import com.manytomanyrelation.repository.CourseRepository;
import com.manytomanyrelation.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private CourseRepository courseRepo;

    public Student createStudent(StudentDTO studentDTO) {
        Student student = new Student();
        student.setName(studentDTO.getName());

        Set<Course> courses = new HashSet<>();
        for (Long courseId : studentDTO.getCourseIds()) {
            Course course = courseRepo.findById(courseId)
                    .orElseThrow(() -> new RuntimeException("Course not found: " + courseId));
            courses.add(course);
        }

        student.setCourses(courses);
        return studentRepo.save(student);
    }

    public Course createCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.setTitle(courseDTO.getTitle());
        return courseRepo.save(course);
    }

    public List<Student> getAllStudents() {
        return studentRepo.findAll();
    }
}
