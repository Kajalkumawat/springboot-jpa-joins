package com.manytomanyrelation.controller;

import com.manytomanyrelation.dto.CourseDTO;
import com.manytomanyrelation.dto.StudentDTO;
import com.manytomanyrelation.entity.Course;
import com.manytomanyrelation.entity.Student;
import com.manytomanyrelation.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/students")
    public ResponseEntity<Student> addStudent(@RequestBody StudentDTO studentDTO) {
        return ResponseEntity.ok(studentService.createStudent(studentDTO));
    }

    @PostMapping("/courses")
    public ResponseEntity<Course> addCourse(@RequestBody CourseDTO courseDTO) {
        return ResponseEntity.ok(studentService.createCourse(courseDTO));
    }

    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudents() {
        return ResponseEntity.ok(studentService.getAllStudents());
    }
}
