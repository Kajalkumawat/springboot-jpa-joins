package com.joins.Joins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
