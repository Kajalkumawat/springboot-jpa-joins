package com.joins.Joins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinsApplication.class, args);
	}

}
