package com.joins.Joins.service;

import com.joins.Joins.dto.OrderDetailsDTO;
import com.joins.Joins.dto.UserDetailsDTO;
import com.joins.Joins.entity.OrderDetails;
import com.joins.Joins.entity.UserDetails;
import com.joins.Joins.repository.UserDetailsRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserDetailsRepository userDetailsRepository;


    public UserService(UserDetailsRepository userDetailsRepository) {
        this.userDetailsRepository = userDetailsRepository;
    }

    public UserDetailsDTO saveUser(UserDetailsDTO dto){
        UserDetails user=new UserDetails();
        user.setName(dto.getName());
        user.setPhone(dto.getPhone());

        List<OrderDetails> orders = dto.getOrderDetails().stream().map(orderDTO -> {
            OrderDetails order = new OrderDetails();
            order.setProductName(orderDTO.getProductName());
            return order;
        }).collect(Collectors.toList());

        user.setOrderDetails(orders);

        UserDetails savedUser = userDetailsRepository.save(user);

        UserDetailsDTO responseDTO = new UserDetailsDTO();
        responseDTO.setName(savedUser.getName());
        responseDTO.setPhone(savedUser.getPhone());

        List<OrderDetailsDTO> orderDTOs = savedUser.getOrderDetails().stream().map(order -> {
            OrderDetailsDTO orderDTO = new OrderDetailsDTO();
            orderDTO.setProductName(order.getProductName());
            return orderDTO;
        }).collect(Collectors.toList());

        responseDTO.setOrderDetails(orderDTOs);
        return responseDTO;
    }
}
