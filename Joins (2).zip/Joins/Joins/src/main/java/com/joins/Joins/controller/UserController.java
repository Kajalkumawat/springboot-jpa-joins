package com.joins.Joins.controller;

import com.joins.Joins.dto.UserDetailsDTO;
import com.joins.Joins.service.UserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/joins")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/add")
    public UserDetailsDTO createUser(@RequestBody UserDetailsDTO userDetailsDTO) {
        return userService.saveUser(userDetailsDTO);
    }
}
