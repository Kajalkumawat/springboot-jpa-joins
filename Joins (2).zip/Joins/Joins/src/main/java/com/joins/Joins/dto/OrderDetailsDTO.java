package com.joins.Joins.dto;

public class OrderDetailsDTO {
    private String productName;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
