package com.joins.Joins.repository;

import com.joins.Joins.entity.OrderDetails;
import com.joins.Joins.entity.UserDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDetailsRepository extends JpaRepository<OrderDetails,Long> {

}
